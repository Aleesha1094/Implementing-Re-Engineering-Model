﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HMS.BAL
{
    public class Prescription
    {
        private string patientCnic;
        private string prescriptionId = "";
        private string medicineName;
        private string medicineCode;
        private string dosage;
        public string PatientCnic
        {
            get
            {
                return patientCnic;
            }
        }
        public string PrescriptionId
        {
            get
            {
                return prescriptionId;
            }
        }
        public string MedicineName
        {
            get
            {
                return medicineName;
            }
        }
        public string MedicineCode
        {
            get
            {
                return medicineCode;
            }
        }
        public string Dosage
        {
            get
            {
                return dosage;
            }
        }
        public Prescription(string patientCnic,string medicineName,string medicineCode,string dosage)
        {
            this.patientCnic = patientCnic;
            this.medicineName = medicineName;
            this.medicineCode = medicineCode;
            this.dosage = dosage;
        }

        /*public Pharmacy Pharmacy
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public Doctor Doctor
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }*/
    }
}
