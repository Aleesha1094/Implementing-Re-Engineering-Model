﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HMS.BAL
{
    public class Login
    {
        private string userName;
        private string password;

        public string UserName
        {
            set
            {
                userName = value;
            }
            get
            {
                return userName;
            }
        }
        public string Password
        {
            set
            {
                password = value;
            }
            get
            {
                return password;
            }
        }
        public Login(string userName,string password)
        {
            this.userName = "Admin";
            this.password = "12345";
        }
    }
}
